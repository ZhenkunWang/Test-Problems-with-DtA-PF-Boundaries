path('problems',path);
global mop params;
tic;
% rng('shuffle') 
cal_igd='yes';
maxruntime=30;
methodname='MOEAD-DRA-UT';
testset={'WOSGZ1','WOSGZ2','WOSGZ3','WOSGZ4','WOSGZ5','WOSGZ6','WOSGZ7','WOSGZ8',...
    'WOSGZ9','WOSGZ10','WOSGZ11','WOSGZ12','WOSGZ13','WOSGZ14','WOSGZ15','WOSGZ16'};
for i=1:length(testset)
    testname=testset{i};
    params = loadparams(testname,methodname);
    for j=1:maxruntime
        [ds,df]  = moead( mop,'popsize',params.popsize,'niche',params.niche,'evaluation',params.evaluation,'selportion',5,'dynamic',1,'seed',177);
         PF{1,j}=df;
         PS{1,j}=ds;
         if strcmp(cal_igd,'yes')
        [PFtrue,~]      = true_pareto(deblank(mop.name),1000,mop.pd );
        igd(j)=IGD(PFtrue,df{end});
%         clc;
        fprintf('The IGD-values in first %d run times for %s testing %s problem\n',j,methodname,testname)
        fprintf('%.4f \n',igd)     
         end
    end
   file_name = strcat('PFandPS_',methodname,testname);
   fold_name=strcat('result_',methodname);
   judge       = exist(fold_name,'dir');
        if judge ~= 7
        system(['mkdir ' fold_name]);
        end 
   file_path= strcat(cd,['\' fold_name '\']);     
   save([file_path,file_name],'PF','PS'); 
    
end

