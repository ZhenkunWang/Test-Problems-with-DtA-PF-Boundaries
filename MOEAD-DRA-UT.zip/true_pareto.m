% pareto.m
% 
% The Matlab source codes to generate the PF and the PS of the test
%   instances for CEC 2009 Multiobjective Optimization Competition.
% 
% Usage: [pf, ps] = pareto(problem_name, no_of_points, variable_dim)
% 
% Please refer to the report for more information.
% 
% History:
%   v1 Sept.08 2008

function [pf, ps] = true_pareto(name, no, dim)

    if nargin<3, dim = 3; end
    if nargin<2, no  = 500; end
    switch name
       case{'WOSGZ1','WOSGZ2','WOSGZ3','WOSGZ4','WOSGZ5','WOSGZ6','WOSGZ7'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-pf(1,:);
            ps          = [];
       case{'WOSGZ8'}
            pf          = zeros(2,no);
            ps(1,:)     = linspace(0,1,no);
            pf(1,:)     = (1-ps(1,:)).^2;
            pf(2,:)     = ps(1,:).^2;
            ps          = [];
        case{'ZDT6'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0.2808,1,no);
            pf(2,:)     = 1-pf(1,:).^2;
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = 0;
        case{'ZDT3'}
            no          = no*4-131;
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-sqrt(pf(1,:))-pf(1,:).*sin(10*pi*pf(1,:)); 
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = 0;
            ParetoF = ParetoFilter(pf);
            ind     = cec09filter(ParetoF,500);
            pf      = (ParetoF(:, ind));
            clear ParetoF ind;
        case {'DTLZ1'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = 0.5*ps(1,:).*ps(2,:);
            pf(2,:)     = 0.5*ps(1,:).*(1-ps(2,:));
            pf(3,:)     = 0.5*(1-ps(1,:));   
            clear s t;
         case {'DTLZ2'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = cos(0.5*pi*ps(1,:)).*cos(0.5*pi*ps(2,:));
            pf(2,:)     = cos(0.5*pi*ps(1,:)).*sin(0.5*pi*ps(2,:));
            pf(3,:)     = sin(0.5*pi*ps(1,:));   
            clear s t;  
         case {'WOSGZ9','WOSGZ10','WOSGZ11','WOSGZ12','WOSGZ13','WOSGZ14','WOSGZ15'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = ps(1,:).*ps(2,:);
            pf(2,:)     = ps(1,:).*(1-ps(2,:));
            pf(3,:)     = 1-ps(1,:);   
            clear s t;   
         case {'WOSGZ16'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf(1,:)     = (ps(1,:).*ps(2,:)).^2;
            pf(2,:)     = (ps(1,:).*(1-ps(2,:))).^2;
            pf(3,:)     = (1-ps(1,:)).^2;   
            clear s t;   
    end
end
