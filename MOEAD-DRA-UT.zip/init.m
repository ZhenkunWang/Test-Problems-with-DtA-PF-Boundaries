function init(mop)
%Set up the initial setting for the MOEA/D.
%loading the params.

    global subproblems params idealpoint parDim objDim;
    idealpoint=ones(mop.od,1)*inf;
    parDim = mop.pd;
    objDim = mop.od;
    subproblems = init_weights(mop.od); 
    params.popsize = length(subproblems);
    
    %initial the subproblem's initital state.
    for i=1:params.popsize
        ind = randompoint(mop);
        [value, ind] = evaluate( mop, ind );
        idealpoint = min(idealpoint, value);
        subproblems(i).curpoint = ind;
        subproblems(i).oldpoint = ind;
    end
end

function subp=init_weights(objDim)
% init_weights function initialize a pupulation of subproblems structure
% with the generated decomposition weight and the neighbourhood
% relationship.
global params;    
    subp = [];

    H = floor(params.popsize^(1/(objDim-1)))-2;
    M = 0;
    while M<params.popsize
       H = H+1;
       M = simplex_weightno(H, 0, objDim); 
    end
    if  isempty(params.H)||params.H~=H
     params.H=H;
     warning('H is redefined because of the inconformity');       
    end
    %to load the parameter from the given file.
    filename = sprintf('weight/W%uD_%u.dat',objDim,params.popsize);
    if (exist(filename, 'file')&&rand<0)
    % copy from the exist file. 
     allws = importdata(filename);
     W = allws';
    else
     W   = zeros(objDim, M);
     C   = 0;
     V   = zeros(objDim,1);
     [W, ~] = simplex_weightset(W, C, V, H, 0, objDim, objDim);
     W   = W / (H+0.0);
    end
     W((W < 1.0E-5))  = 1.0E-6;
     v  = squareform(pdist(W'));
     %Set up the neighbourhood.
%     if  strcmp(params.dmethod,'ts')
%      W=(1./W)./repmat(sum(1./W),[objDim 1]);
%     end
    if params.popsize~=M %correct the populaiton size
     params.popsize=M;
     error('Population size is redefined because of the inconformity');
    end   
    p=get_structure('subproblem');
    subp=repmat(p,1,params.popsize);
    Wcells = mat2cell(W, objDim, ones(1, size(W,2)));
    [subp.weight] = Wcells{:};

    %Set up the neighbourhood.
    leng=length(subp);
    for i=1:leng
        [s,sindex]=sort(v(i,:));
        subp(i).neighbour=sindex(1:params.niche)';
    end
end
function M = simplex_weightno(unit, sum, dim)

M = 0;

if dim == 1
    M = 1; 
    return;
end

for i=0:1:(unit - sum)
    M = M + simplex_weightno(unit, sum+i, dim-1);
end

end
function [w, c] =simplex_weightset(w, c, v, unit, sum, objdim, dim)

if dim == objdim
    v = zeros(objdim, 1);
end

if dim == 1
    c       = c+1;
    v(1)    = unit-sum;
    w(:,c)  = v;
    return;
end

for i=0:1:(unit - sum)
    v(dim)  = i;
    [w, c]  = simplex_weightset(w, c, v, unit, sum+i, objdim, dim-1);
end

end
