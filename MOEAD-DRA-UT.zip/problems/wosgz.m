function mop = wosgz( testname, dimension )
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.

    mop=get_structure('testmop');   
    switch lower(testname)
        case 'wosgz1'
            mop=wosgz1(mop, dimension);
        case 'wosgz2'
            mop=wosgz2(mop, dimension);
        case 'wosgz3'
            mop=wosgz3(mop, dimension);
        case 'wosgz4'
            mop=wosgz4(mop, dimension);
        case 'wosgz5'
            mop=wosgz5(mop, dimension);     
        case 'wosgz6'
            mop=wosgz6(mop, dimension); 
        case 'wosgz7'
            mop=wosgz7(mop, dimension); 
        case 'wosgz8'
            mop=wosgz8(mop, dimension); 
        case 'wosgz9'
            mop=wosgz9(mop, dimension);      
        case 'wosgz10'
            mop=wosgz10(mop, dimension); 
        case 'wosgz11'
            mop=wosgz11(mop, dimension); 
        case 'wosgz12'
            mop=wosgz12(mop, dimension); 
        case 'wosgz13'
            mop=wosgz13(mop, dimension); 
        case 'wosgz14'
            mop=wosgz14(mop, dimension); 
        case 'wosgz15'
            mop=wosgz15(mop, dimension); 
        case 'wosgz16'
            mop=wosgz16(mop, dimension);              
        otherwise 
            error('Undefined test problem name');                
    end 
end

function p = wosgz1(p,dim)
 p.name = 'WOSGZ1';
 p.pd = dim;
 p.od = 2;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
  function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=1;
    B=4;
    C=2;
    D=4;
    E=3;
   %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;%the real vector is cor*(1/M), the real length of cor is sqrt(1/(M*(M-1)))
    r=sqrt((M-1)/M)*max(cor*(X-1/M));% 1/M / sqrt(1/(M*(M-1))) = sqrt((M-1)/M)
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
  end
end
%%
function p = wosgz2(p,dim)
 p.name = 'WOSGZ2';
 p.pd = dim;
 p.od = 2;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
  function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=2;
    B=4;
    C=2;
    D=4;
    E=3;
   %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz3(p,dim)
 p.name = 'WOSGZ3';
 p.pd = dim;
 p.od = 2;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
  function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=2;
    B=2;
    C=2;
    D=2;
    E=3;
   %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz4(p,dim)
 p.name = 'WOSGZ4';
 p.pd = dim;
 p.od = 2;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
  function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=3;
    B=2;
    C=2;
    D=2;
    E=3;
   %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz5(p,dim)
 p.name = 'WOSGZ5';
 p.pd = dim;
 p.od = 2;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=3;
    B=1;
    C=2;
    D=1;
    E=3;
   %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz6(p,dim)
 p.name = 'WOSGZ6';
 p.pd = dim;
 p.od = 2;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=4;
    B=1;
    C=2;
    D=1;
    E=3;
   %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz7(p,dim)
 p.name = 'WOSGZ7';
 p.pd = dim;
 p.od = 2;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=2;
    B=2;
    C=0.8;
    D=2;
    E=3;
   %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz8(p,dim)
 p.name = 'WOSGZ8';
 p.pd = dim;
 p.od = 2;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=2;
    B=2;
    C=2;
    D=2;
    E=3;
   %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X.^2+g;
 end
end
%%
function p = wosgz9(p,dim)
 p.name = 'WOSGZ9';
 p.pd = dim;
 p.od = 3;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=1;
    B=4;
    C=2;
    D=4;
    E=3;
    %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz10(p,dim)
 p.name = 'WOSGZ10';
 p.pd = dim;
 p.od = 3;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=2;
    B=4;
    C=2;
    D=4;
    E=3;
    %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz11(p,dim)
 p.name = 'WOSGZ11';
 p.pd = dim;
 p.od = 3;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
  function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=2;
    B=2;
    C=2;
    D=2;
    E=3;
    %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
  end
end
%%
function p = wosgz12(p,dim)
 p.name = 'WOSGZ12';
 p.pd = dim;
 p.od = 3;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=3;
    B=2;
    C=2;
    D=2;
    E=3;
    %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz13(p,dim)
 p.name = 'WOSGZ13';
 p.pd = dim;
 p.od = 3;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=3;
    B=1;
    C=2;
    D=1;
    E=3;
    %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz14(p,dim)
 p.name = 'WOSGZ14';
 p.pd = dim;
 p.od = 3;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=4;
    B=1;
    C=2;
    D=1;
    E=3;
    %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
 end
end
%%
function p = wosgz15(p,dim)
 p.name = 'WOSGZ15';
 p.pd = dim;
 p.od = 3;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=2;
    B=2;
    C=0.8;
    D=2;
    E=3;
    %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X+g;
end
end
%%
function p = wosgz16(p,dim)
 p.name = 'WOSGZ16';
 p.pd = dim;
 p.od = 3;
 p.domain = [repmat([0,1],p.od-1,1);-1*ones(dim-p.od+1,1),ones(dim-p.od+1,1)];
 p.func = @evaluate;
 function y = evaluate(x)    
    n = size(x,1);
    M=p.od;
    X=zeros(M,1);
    g=zeros(M,1);
    J=cell(M,1);
    Jsize=zeros(M,1);
    co_r=ones(M,M)/(M-1);
    R=zeros(M,1);
    %%
    A=2;
    B=2;
    C=2;
    D=2;
    E=3;
    %%
    X(1)=(1-x(1));
    X(M)=prod(x(1:M-1,1));
    for i=2:M-1
          X(i)=prod(x(1:i-1,1))*(1-x(i));
    end 
    %%
    cor=-M*diag(diag(co_r))+co_r;
    r=sqrt((M-1)/M)*max(cor*(X-1/M));
    R(1:M-1)=1/(M-1)-1/M;
    R(M)=-1/M;
    R_long=sqrt(sum(R.^2));
    h=(r/R_long);
    theta=h.^(M-1);
    Y_bias=A*(sin(0.5*pi*theta)^D)+1;
    X_bias=0.9*(sin(0.5*pi*theta)^B);
    %%
    t=x(M:n)-X_bias*cos(E*pi*repmat(h,[1,n-M+1])+0.5*pi*(n+2)*(M:n)/n)';
    J{1}=M:M:n;
    Jsize(1)=length(J{1});
    g(1)=Y_bias/Jsize(1)*sum(abs(t(J{1}-M+1)).^C);   
    J{M}=2*M-1:M:n;
    Jsize(M)=length(J{M});
    g(M)=Y_bias/Jsize(M)*sum(abs(t(J{M}-M+1)).^C);   
    for j=2:M-1
        J{j}=M+j-1:M:n;
        Jsize(j)=length(J{j});
        g(j)=Y_bias/Jsize(j)*sum(abs(t(J{j}-M+1)).^C);   
    end    
y=X.^2+g;
end
end
