function testmop( testname, pdim)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.
global mop;
mop=struct('name',[],'od',[],'pd',[],'domain',[],'func',[]);
    switch lower(testname)
        case {'zdt1','zdt2','zdt3','zdt4','zdt5','zdt6'}
            mop=zdt(testname,pdim);
        case {'dtlz1','dtlz2','dtlz3','dtlz4','dtlz5','dtlz6','dtlz7'}
            odim=3;
            mop=dtlz(testname,pdim,odim);
        case {'wosgz1','wosgz2','wosgz3','wosgz4','wosgz5','wosgz6','wosgz7','wosgz8',...
              'wosgz9','wosgz10','wosgz11','wosgz12','wosgz13','wosgz14','wosgz15','wosgz16'}
            mop=wosgz(testname,pdim); 
        otherwise 
            error('Undefined test problem name'); 
    end    
end